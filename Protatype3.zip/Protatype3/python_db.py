import psycopg2
import requests

db_config = {
    'dbname': 'data',
    'user': 'postgres',
    'password': '1234567890',
    'host': 'localhost'
}

api_key = '617827a88878fb36cb2c3c1650e82180'
city = 'Bukhara'  

url = f'http://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}'

try:
    response = requests.get(url)
    if response.status_code == 200:
        weather_data = response.json()

        weather_description = weather_data['weather'][0]['description']
        temperature = weather_data['main']['temp']
        humidity = weather_data['main']['humidity']
        wind_speed = weather_data['wind']['speed']

        conn = psycopg2.connect(**db_config)
        cursor = conn.cursor()

        insert_query = "INSERT INTO weather_data (city, description, temperature, humidity, wind_speed) VALUES (%s, %s, %s, %s, %s)"
        data = (city, weather_description, temperature, humidity, wind_speed)
        
        print(data)

        cursor.execute(insert_query, data)
        conn.commit()

        print("Weather data inserted successfully")

        cursor.close()
        conn.close()
    else:
        print("Failed to fetch data from OpenWeatherMap API")
except Exception as e:
    print("An error occurred:", e)
